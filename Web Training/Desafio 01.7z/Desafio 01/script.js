const whoClick = (whatButton) => {
    alert(`Você clickou no ${whatButton}º botão!`)
}